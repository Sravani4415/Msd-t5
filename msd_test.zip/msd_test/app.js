// app.js
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());

// Path to books.json
const DATA_FILE = path.join(__dirname, 'books.json');

// Helper: Read books from file
function readBooks() {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(data || '[]');
  } catch (err) {
    console.error('Error reading file:', err);
    return [];
  }
}

// Helper: Write books to file
function writeBooks(books) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(books, null, 2), 'utf8');
  } catch (err) {
    console.error('Error writing file:', err);
  }
}

// GET /books → return all books
app.get('/books', (req, res) => {
  const books = readBooks();
  res.json(books);
});

// BONUS: GET /books/available → return only available books
app.get('/books/available', (req, res) => {
  const books = readBooks();
  const availableBooks = books.filter(book => book.available === true);
  res.json(availableBooks);
});

// POST /books → add new book
app.post('/books', (req, res) => {
  const { title, author, available } = req.body;

  if (!title || !author || typeof available !== 'boolean') {
    return res.status(400).json({ error: 'Invalid book data.' });
  }

  const books = readBooks();
  const newId = books.length > 0 ? Math.max(...books.map(b => b.id)) + 1 : 1;

  const newBook = { id: newId, title, author, available };
  books.push(newBook);
  writeBooks(books);

  res.status(201).json(newBook);
});

// PUT /books/:id → update a book
app.put('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);
  const { title, author, available } = req.body;

  const books = readBooks();
  const bookIndex = books.findIndex(b => b.id === bookId);

  if (bookIndex === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  // Update fields only if provided
  if (title !== undefined) books[bookIndex].title = title;
  if (author !== undefined) books[bookIndex].author = author;
  if (available !== undefined) books[bookIndex].available = available;

  writeBooks(books);
  res.json(books[bookIndex]);
});

// DELETE /books/:id → delete a book
app.delete('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);
  const books = readBooks();
  const bookIndex = books.findIndex(b => b.id === bookId);

  if (bookIndex === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  const deletedBook = books.splice(bookIndex, 1)[0];
  writeBooks(books);
  res.json(deletedBook);
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
// Root route - just a welcome message
app.get('/', (req, res) => {
  res.send('📚 Welcome to the Books API! Use /books or /books/available');
});
